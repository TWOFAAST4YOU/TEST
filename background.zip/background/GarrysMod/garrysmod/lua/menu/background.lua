local BackgroundPanel = nil
local CurrentFrame = 1
local FrameCount = 0
_G.IsMuted = false -- Global for external access, persists mute state
local IsReady = false
local WasInMenu = true -- Track previous menu state
local AudioURL = "asset://garrysmod/html/video/background.mp3"
local LastMuteToggle = 0
local MuteCooldown = 0.5 -- 0.5-second cooldown

local ShouldBackgroundUpdate = function()
    return not IsInGame() and not IsInLoading()
end

local GetFramePath = function(frame)
    local base = "html/frames/frame_" .. string.format("%04d", frame)
    if file.Exists(base .. ".png", "GAME") then
        return base .. ".png"
    elseif file.Exists(base .. ".jpg", "GAME") then
        return base .. ".jpg"
    end
    return base .. ".png"
end

local CountFrames = function()
    local i = 1
    while file.Exists("html/frames/frame_" .. string.format("%04d", i) .. ".jpg", "GAME") or
          file.Exists("html/frames/frame_" .. string.format("%04d", i) .. ".png", "GAME") do
        i = i + 1
    end
    return math.max(i - 1, 1)
end

local InitializeBackground = function()
    if IsValid(BackgroundPanel) then return end -- Prevent multiple initializations
    
    FrameCount = CountFrames()
    
    BackgroundPanel = vgui.Create("DHTML")
    BackgroundPanel:SetSize(ScrW(), ScrH())
    BackgroundPanel:SetPos(0, 0)
    BackgroundPanel:SetZPos(-1000)
    BackgroundPanel:SetMouseInputEnabled(false)
    BackgroundPanel:SetPaintedManually(true)
    BackgroundPanel:SetAlpha(0) -- Start invisible
    
    local htmlContent = [[
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body, html {
                    margin: 0;
                    padding: 0;
                    overflow: hidden;
                    background: black;
                    width: 100%;
                    height: 100%;
                }
                #frameImage {
                    width: 100vw;
                    height: 100vh;
                    object-fit: cover;
                    position: absolute;
                    top: 0;
                    left: 0;
                    transition: opacity 0.3s;
                }
                #frameImage.muted {
                    opacity: 0.7;
                }
            </style>
        </head>
        <body>
            <img id="frameImage" src="]] .. GetFramePath(1) .. [[">
            <audio id="bgAudio" preload="auto" loop>
                <source src="]] .. AudioURL .. [[" type="audio/mpeg">
            </audio>
            <script>
                var frameCount = ]] .. FrameCount .. [[;
                var imageElement = document.getElementById('frameImage');
                var audioElement = document.getElementById('bgAudio');
                audioElement.volume = 1;
                var lastTime = performance.now();
                var elapsed = 0;
                var frameRate = 0;
                var totalDuration = 0;
                var frameDuration = 0;
                var lastFrame = 0;
                var isPlaying = false;
                var animationFrameId = null;

                function getFramePath(frame) {
                    var base = 'asset://garrysmod/html/frames/frame_' + String(frame).padStart(4, '0');
                    return base + '.png';
                }

                function calculateFrameRate() {
                    totalDuration = audioElement.duration;
                    frameRate = frameCount / totalDuration;
                    frameDuration = 1000 / frameRate;
                }

                function getCurrentFrame() {
                    var audioTime = audioElement.currentTime;
                    var targetFrame = Math.floor(audioTime * frameRate) + 1;
                    return Math.min(Math.max(targetFrame, 1), frameCount);
                }

                function updateFrame(timestamp) {
                    if (!frameRate || !isPlaying) return;
                    var delta = timestamp - lastTime;
                    lastTime = timestamp;
                    elapsed += delta;

                    var currentFrame = getCurrentFrame();
                    if (elapsed >= frameDuration && currentFrame !== lastFrame) {
                        elapsed = 0;
                        imageElement.src = getFramePath(currentFrame);
                        lastFrame = currentFrame;
                    }

                    animationFrameId = requestAnimationFrame(updateFrame);
                }

                function resetAnimation() {
                    audioElement.currentTime = 0;
                    imageElement.src = getFramePath(1);
                    lastFrame = 0;
                    elapsed = 0;
                    lastTime = performance.now();
                }

                function startPlayback() {
                    if (!frameRate) calculateFrameRate();
                    resetAnimation();
                    audioElement.play().then(() => {
                        isPlaying = true;
                        animationFrameId = requestAnimationFrame(updateFrame);
                    }).catch(e => console.log('Playback failed: ' + e));
                }

                function stopPlayback() {
                    if (animationFrameId) {
                        cancelAnimationFrame(animationFrameId);
                        animationFrameId = null;
                    }
                    audioElement.pause();
                    isPlaying = false;
                }

                audioElement.addEventListener('loadedmetadata', function() {
                    calculateFrameRate();
                    if (!isPlaying) startPlayback();
                });

                audioElement.addEventListener('ended', function() {
                    resetAnimation();
                    audioElement.play();
                });

                function toggleMute(state) {
                    audioElement.volume = state ? 0 : 1;
                    window.gmod_call('SetMuteState', state ? 'true' : 'false');
                    if (state) {
                        imageElement.classList.add('muted');
                    } else {
                        imageElement.classList.remove('muted');
                    }
                }

                function restart() {
                    stopPlayback();
                    resetAnimation();
                    startPlayback();
                }

                window.gmod_call = function(func, value) {
                    window.location = 'gmod://' + func + '/' + value;
                };

                // Expose stop and start for Lua control
                window.stopPlayback = stopPlayback;
                window.startPlayback = startPlayback;

                // Initial setup
                startPlayback();
            </script>
        </body>
        </html>
    ]]
    
    BackgroundPanel:SetHTML(htmlContent)
    BackgroundPanel:AlphaTo(255, 0.5, 0, function()
        IsReady = true
        print("Background initialized with " .. FrameCount .. " frames")
        BackgroundPanel:Call("toggleMute(" .. (_G.IsMuted and "true" or "false") .. ");")
    end)
end

-- Global ToggleBackgroundMute function, restricted to main menu
function _G.ToggleBackgroundMute(state)
    if not ShouldBackgroundUpdate() then return end -- Only works in main menu
    if IsValid(BackgroundPanel) then
        local currentTime = CurTime()
        if currentTime - LastMuteToggle >= MuteCooldown then
            local newState = state ~= nil and state or not _G.IsMuted
            _G.IsMuted = newState
            BackgroundPanel:Call("toggleMute(" .. (newState and "true" or "false") .. ");")
            LastMuteToggle = currentTime
            print("Mute toggled to: " .. tostring(newState))
        end
    end
end

local function RestartBackground()
    if IsValid(BackgroundPanel) then
        print("Restarting background")
        BackgroundPanel:Call("restart();")
        BackgroundPanel:Call("toggleMute(" .. (_G.IsMuted and "true" or "false") .. ");")
    end
end

hook.Add("HTMLCallback", "SetMuteState", function(url, args)
    if url == "SetMuteState" then
        _G.IsMuted = (args[1] == "true")
    end
end)

function DrawBackground()
    if not IsValid(BackgroundPanel) then return end
    
    local inMenu = ShouldBackgroundUpdate()
    
    if not inMenu then
        if WasInMenu then -- Only stop playback when transitioning out of menu
            print("Stopping playback (in-game/loading)")
            BackgroundPanel:Call("stopPlayback();")
            if not _G.IsMuted then
                _G.IsMuted = true
                BackgroundPanel:Call("toggleMute(true);")
            end
        end
        BackgroundPanel:SetAlpha(0) -- Hide panel
    else
        BackgroundPanel:SetAlpha(255) -- Show panel
        if not WasInMenu then
            print("Returning to menu, restarting with mute state: " .. tostring(_G.IsMuted))
            RestartBackground()
        elseif not IsReady then
            return -- Skip painting until ready
        end
        BackgroundPanel:PaintManual() -- Paint only when in menu
    end
    
    WasInMenu = inMenu -- Update previous state
end

function ClearBackgroundImages()
    CurrentFrame = 1
    IsReady = false
    FrameCount = 0
    if IsValid(BackgroundPanel) then
        BackgroundPanel:Call("stopPlayback();") -- Ensure stopped before removal
        BackgroundPanel:Remove()
        BackgroundPanel = nil
    end
    collectgarbage("collect")
end

function AddBackgroundImage(img)
    if not img or type(img) != "string" then return end
    local frameNum = FrameCount + 1
    if frameNum <= CurrentFrame then return end
    
    FrameCount = frameNum
    if IsValid(BackgroundPanel) then
        BackgroundPanel:Call("frameCount = " .. FrameCount .. "; calculateFrameRate();")
    end
end

function ChangeBackground(currentgm)
    ClearBackgroundImages()
    InitializeBackground()
end

function UpdateBackgroundImages()
    ChangeBackground()
end

-- Alt + M detection with cooldown, restricted to main menu
hook.Add("Think", "CheckAltMMute", function()
    if not ShouldBackgroundUpdate() then return end -- Only in menu
    
    if input.IsKeyDown(KEY_LALT) and input.IsKeyDown(KEY_M) then
        local currentTime = CurTime()
        if currentTime - LastMuteToggle >= MuteCooldown then
            _G.ToggleBackgroundMute(not _G.IsMuted)
            LastMuteToggle = currentTime
        end
    end
end)

hook.Add("InitPostEntity", "SetupMenuBackground", function()
    timer.Simple(2, InitializeBackground)
end)
hook.Add("HUDPaintBackground", "RenderMenuBackground", DrawBackground)
hook.Add("ShutDown", "CleanupMenuBackground", ClearBackgroundImages)

if not MainMenu then MainMenu = {} end
MainMenu.UpdateBackgroundImages = UpdateBackgroundImages
MainMenu.DrawBackground = DrawBackground
MainMenu.ClearBackgroundImages = ClearBackgroundImages
MainMenu.ChangeBackground = ChangeBackground