@echo off
color 0a
setlocal EnableDelayedExpansion

:: Log file setup
set "log_file=%~dp0debug.log"
echo [%date% %time%] Starting script... > "!log_file!"

:load_settings
echo Loading settings...
echo [%date% %time%] Loading settings... >> "!log_file!"
if not exist "settings.txt" (
    echo No settings file found! Initializing...
    echo [%date% %time%] No settings.txt found, prompting for initial setup >> "!log_file!"
    set /p "video_path=Enter video path (or press Enter for default): " || set "video oasis_path=%CD%\videos"
    set /p "frames_path=Enter frames path (or press Enter for default): " || set "frames_path=%CD%\frames"
    set /p "ffmpeg_path=Enter full path to ffmpeg.exe (e.g., C:\ffmpeg\bin\ffmpeg.exe): " || (
        echo Error: FFmpeg path is required!
        echo [%date% %time%] Error: FFmpeg path not provided during initial setup >> "!log_file!"
        pause
        exit /b 1
    )
    if "!video_path!"=="" set "video_path=%CD%\videos"
    if "!frames_path!"=="" set "frames_path=%CD%\frames"
    if not exist "!ffmpeg_path!" (
        echo Error: "!ffmpeg_path!" does not exist!
        echo [%date% %time%] Error: FFmpeg path "!ffmpeg_path!" does not exist >> "!log_file!"
        pause
        exit /b 1
    )
    >settings.txt (
        echo video_path=!video_path!
        echo frames_path=!frames_path!
        echo ffmpeg_path=!ffmpeg_path!
    )
    echo [%date% %time%] Settings initialized: video_path="!video_path!", frames_path="!frames_path!", ffmpeg_path="!ffmpeg_path!" >> "!log_file!"
) else (
    set "video_path="
    set "frames_path="
    set "ffmpeg_path="
    for /f "tokens=1,2 delims==" %%a in (settings.txt) do (
        if "%%a"=="video_path" set "video_path=%%b"
        if "%%a"=="frames_path" set "frames_path=%%b"
        if "%%a"=="ffmpeg_path" set "ffmpeg_path=%%b"
    )
    if "!ffmpeg_path!"=="" (
        echo Error: FFmpeg path not set in settings.txt!
        echo [%date% %time%] Error: FFmpeg path missing in settings.txt >> "!log_file!"
        goto :update_ffmpeg_path
    )
    if not exist "!ffmpeg_path!" (
        echo Error: FFmpeg path "!ffmpeg_path!" from settings.txt is invalid!
        echo [%date% %time%] Error: FFmpeg path "!ffmpeg_path!" invalid >> "!log_file!"
        goto :update_ffmpeg_path
    )
)
echo Video path: !video_path!
echo Frames path: !frames_path!
echo FFmpeg path: !ffmpeg_path!
echo [%date% %time%] Loaded settings: video_path="!video_path!", frames_path="!frames_path!", ffmpeg_path="!ffmpeg_path!" >> "!log_file!"

:: Test FFmpeg accessibility
echo Testing FFmpeg...
echo [%date% %time%] Testing FFmpeg accessibility... >> "!log_file!"
"!ffmpeg_path!" -version >nul 2>>"!log_file!"
if errorlevel 1 (
    echo Error: FFmpeg at "!ffmpeg_path!" is not accessible or invalid!
    echo [%date% %time%] Error: FFmpeg test failed with errorlevel !errorlevel! >> "!log_file!"
    pause
    goto :update_ffmpeg_path
)
echo FFmpeg test passed.
echo [%date% %time%] FFmpeg test passed >> "!log_file!"

goto :settings_loaded

:update_ffmpeg_path
set /p "ffmpeg_path=Please enter the full path to ffmpeg.exe (e.g., C:\ffmpeg\bin\ffmpeg.exe): " || (
    echo Error: FFmpeg path is required!
    echo [%date% %time%] Error: FFmpeg path not provided in update >> "!log_file!"
    pause
    exit /b 1
)
if not exist "!ffmpeg_path!" (
    echo Error: "!ffmpeg_path!" does not exist!
    echo [%date% %time%] Error: FFmpeg path "!ffmpeg_path!" does not exist in update >> "!log_file!"
    pause
    goto :update_ffmpeg_path
)
>settings.txt (
    echo video_path=!video_path!
    echo frames_path=!frames_path!
    echo ffmpeg_path=!ffmpeg_path!
)
echo [%date% %time%] FFmpeg path updated to: "!ffmpeg_path!" >> "!log_file!"
goto :settings_loaded

:settings_loaded
echo Using FFmpeg at: !ffmpeg_path!
echo [%date% %time%] Using FFmpeg at: "!ffmpeg_path!" >> "!log_file!"
echo.

:main_menu
cls
echo === Video Processing Tool ===
echo 1. Process Video
echo 2. Change Settings
echo 3. Exit
echo ======================
set "menu="
set /p "menu=Select option (1-3): " || set "menu=invalid"
echo [%date% %time%] Main menu input: "!menu!" >> "!log_file!"
if "!menu!"=="1" goto process_video
if "!menu!"=="2" goto settings_menu
if "!menu!"=="3" (
    echo [%date% %time%] Exiting script >> "!log_file!"
    exit /b 0
)
echo Invalid menu option: !menu!
echo [%date% %time%] Invalid menu option: "!menu!" >> "!log_file!"
pause
goto main_menu

:settings_menu
cls
echo === Settings ===
echo Current Video Path: !video_path!
echo Current Frames Path: !frames_path!
echo Current FFmpeg Path: !ffmpeg_path!
echo 1. Change Video Path
echo 2. Change Frames Path
echo 3. Change FFmpeg Path
echo 4. Back to Main Menu
set "set_choice="
set /p "set_choice=Select option (1-4): " || set "set_choice=invalid"
echo [%date% %time%] Settings menu input: "!set_choice!" >> "!log_file!"
if "!set_choice!"=="1" (
    set /p "video_path=New video path (or press Enter for default): " || set "video_path=%CD%\videos"
    if "!video_path!"=="" set "video_path=%CD%\videos"
) else if "!set_choice!"=="2" (
    set /p "frames_path=New frames path (or press Enter for default): " || set "frames_path=%CD%\frames"
    if "!frames_path!"=="" set "frames_path=%CD%\frames"
) else if "!set_choice!"=="3" (
    set /p "ffmpeg_path=New FFmpeg path (full path to ffmpeg.exe): " || (
        echo Error: FFmpeg path cannot be empty!
        echo [%date% %time%] Error: FFmpeg path empty in settings menu >> "!log_file!"
        pause
        goto settings_menu
    )
    if not exist "!ffmpeg_path!" (
        echo Error: "!ffmpeg_path!" does not exist!
        echo [%date% %time%] Error: FFmpeg path "!ffmpeg_path!" does not exist in settings menu >> "!log_file!"
        pause
        goto settings_menu
    )
) else if "!set_choice!"=="4" goto main_menu
else (
    echo Invalid settings option: !set_choice!
    echo [%date% %time%] Invalid settings option: "!set_choice!" >> "!log_file!"
    pause
    goto settings_menu
)
>settings.txt (
    echo video_path=!video_path!
    echo frames_path=!frames_path!
    echo ffmpeg_path=!ffmpeg_path!
)
echo Settings updated.
echo [%date% %time%] Settings updated: video_path="!video_path!", frames_path="!frames_path!", ffmpeg_path="!ffmpeg_path!" >> "!log_file!"
pause
goto settings_menu

:process_video
echo Processing video...
echo [%date% %time%] Starting video processing... >> "!log_file!"
if not exist "!video_path!" (
    mkdir "!video_path!" || (
        echo Error: Failed to create directory "!video_path!"
        echo [%date% %time%] Error: Failed to create video directory "!video_path!" >> "!log_file!"
        pause
        goto main_menu
    )
)
if not exist "!frames_path!" (
    mkdir "!frames_path!" || (
        echo Error: Failed to create directory "!frames_path!"
        echo [%date% %time%] Error: Failed to create frames directory "!frames_path!" >> "!log_file!"
        pause
        goto main_menu
    )
)

echo === Available Videos ===
set "count=0"
for %%f in ("!video_path!\*.mp4") do (
    set /a "count+=1"
    set "file[!count!]=%%f"
    echo !count!. %%~nxf
)
echo [%date% %time%] Found !count! videos in "!video_path!" >> "!log_file!"
if !count! equ 0 (
    echo No videos found! Drag-drop a file or enter path:
    set "video_file="
    set /p "video_file=Video path: " || goto main_menu
    if "!video_file!"=="" goto main_menu
) else (
    set "choice="
    set /p "choice=Select video (1-!count!) or 0 for drag-drop: " || set "choice=invalid"
    echo [%date% %time%] Video selection input: "!choice!" >> "!log_file!"
    if "!choice!"=="0" (
        set "video_file="
        set /p "video_file=Drag-drop or enter path: " || goto main_menu
        if "!video_file!"=="" goto main_menu
    ) else if "!choice!" geq "1" if "!choice!" leq "!count!" (
        call set "video_file=%%file[!choice!]%%"
    ) else (
        echo Invalid choice: !choice!
        echo [%date% %time%] Invalid video choice: "!choice!" >> "!log_file!"
        pause
        goto main_menu
    )
)

if not exist "!video_file!" (
    echo Error: Video file "!video_file!" not found!
    echo [%date% %time%] Error: Video file "!video_file!" not found >> "!log_file!"
    pause
    goto main_menu
)
echo [%date% %time%] Selected video: "!video_file!" >> "!log_file!"

echo === Resolution ===
echo 0. Original  1. 720p  2. 1080p  3. 1440p  4. Custom
set "res="
set /p "res=Select (0-4): " || set "res=0"
echo [%date% %time%] Resolution input: "!res!" >> "!log_file!"
if "!res!"=="1" (
    set "scale=-vf scale=1280:720"
) else if "!res!"=="2" (
    set "scale=-vf scale=1920:1080"
) else if "!res!"=="3" (
    set "scale=-vf scale=2560:1440"
) else if "!res!"=="4" (
    set /p "custom_width=Enter width (e.g., 1920): " || (
        echo Error: Width is required for custom resolution!
        echo [%date% %time%] Error: Custom width not provided >> "!log_file!"
        pause
        goto main_menu
    )
    set /p "custom_height=Enter height (e.g., 1080): " || (
        echo Error: Height is required for custom resolution!
        echo [%date% %time%] Error: Custom height not provided >> "!log_file!"
        pause
        goto main_menu
    )
    set "scale=-vf scale=!custom_width!:!custom_height!"
    echo Custom resolution set to: !custom_width!x!custom_height!
    echo [%date% %time%] Custom resolution set to: !custom_width!x!custom_height! >> "!log_file!"
) else (
    set "scale="
)
echo Selected resolution: !scale!
echo [%date% %time%] Selected resolution: "!scale!" >> "!log_file!"

echo === Format ===
echo 1. JPG  2. PNG
set "fmt="
set /p "fmt=Select (1-2): " || set "fmt=1"
echo [%date% %time%] Format input: "!fmt!" >> "!log_file!"
if "!fmt!"=="1" (set "img_format=jpg") else if "!fmt!"=="2" (set "img_format=png") else (set "img_format=jpg")
echo Selected format: !img_format!
echo [%date% %time%] Selected format: "!img_format!" >> "!log_file!"

echo === Frame Rate ===
echo 1. Original  2. 20fps  3. 30fps  4. 60fps  5. Custom
set "fps="
set /p "fps=Select (1-5): " || set "fps=invalid"
echo [%date% %time%] FPS input: "!fps!" >> "!log_file!"
if "!fps!"=="1" (
    set "fps_rate="
    echo FPS set to original
    echo [%date% %time%] FPS set to original >> "!log_file!"
) else if "!fps!"=="2" (
    set "fps_rate=20"
    echo FPS set to 20
    echo [%date% %time%] FPS set to 20 >> "!log_file!"
) else if "!fps!"=="3" (
    set "fps_rate=30"
    echo FPS set to 30
    echo [%date% %time%] FPS set to 30 >> "!log_file!"
) else if "!fps!"=="4" (
    set "fps_rate=60"
    echo FPS set to 60
    echo [%date% %time%] FPS set to 60 >> "!log_file!"
) else if "!fps!"=="5" (
    set /p "fps_rate=Enter custom FPS (e.g., 45): " || (
        echo Error: Custom FPS is required!
        echo [%date% %time%] Error: Custom FPS not provided >> "!log_file!"
        pause
        goto main_menu
    )
    echo FPS set to custom: !fps_rate!
    echo [%date% %time%] FPS set to custom: !fps_rate! >> "!log_file!"
) else (
    echo Error: Invalid FPS selection: "!fps!"
    echo [%date% %time%] Error: Invalid FPS selection: "!fps!" >> "!log_file!"
    pause
    goto main_menu
)
echo Proceeding with FPS: !fps! ^(rate: !fps_rate!^)
echo [%date% %time%] Proceeding with FPS: !fps! (rate: !fps_rate!) >> "!log_file!"

echo === Image Quality ===
echo Enter a value between 2 (highest) and 31 (lowest), or press Enter for default (1 - maximum quality):
set "quality="
set /p "quality=Quality (2-31): " || set "quality=1"
echo [%date% %time%] Quality input: "!quality!" >> "!log_file!"
if "!quality!" lss "2" if not "!quality!"=="1" (
    echo Error: Quality must be 1 or between 2 and 31!
    echo [%date% %time%] Error: Invalid quality "!quality!" >> "!log_file!"
    pause
    goto main_menu
) else if "!quality!" gtr "31" (
    echo Error: Quality must be 1 or between 2 and 31!
    echo [%date% %time%] Error: Invalid quality "!quality!" >> "!log_file!"
    pause
    goto main_menu
)
set "quality_setting=-q:v !quality!"
echo Image quality set to: !quality!
echo [%date% %time%] Image quality set to: !quality! >> "!log_file!"

:: Get video duration
echo Getting video duration...
echo [%date% %time%] Getting video duration for "!video_file!"... >> "!log_file!"
set "total_seconds=0"
set "temp_file=%TEMP%\ffmpeg_duration.txt"
set "duration_cmd="!ffmpeg_path!" -hide_banner -i "!video_file!" 2^>^&1"
echo [%date% %time%] Duration command: !duration_cmd! ^> "!temp_file!" >> "!log_file!"
!duration_cmd! >"!temp_file!" 2>&1
if errorlevel 1 (
    echo Error: FFmpeg failed to retrieve video info!
    echo [%date% %time%] Error: FFmpeg failed with errorlevel !errorlevel! >> "!log_file!"
    type "!temp_file!" >> "!log_file!"
    del "!temp_file!"
    pause
    goto main_menu
)
for /f "tokens=2 delims=, " %%i in ('type "!temp_file!" ^| find "Duration"') do (
    set "duration=%%i"
    echo Duration raw: "!duration!"
    echo [%date% %time%] Duration raw: "!duration!" >> "!log_file!"
    for /f "tokens=1-4 delims=:." %%a in ("!duration!") do (
        set /a "total_seconds=%%a*3600 + %%b*60 + %%c" 2>nul || (
            echo Error: Failed to parse duration: "!duration!"
            echo [%date% %time%] Error: Failed to parse duration: "!duration!" >> "!log_file!"
            del "!temp_file!"
            pause
            goto main_menu
        )
    )
)
del "!temp_file!"
if !total_seconds! equ 0 (
    echo Error: Could not determine video duration!
    echo [%date% %time%] Error: Could not determine video duration >> "!log_file!"
    echo [%date% %time%] Running FFmpeg info for debugging: >> "!log_file!"
    "!ffmpeg_path!" -hide_banner -i "!video_file!" 2>>"!log_file!"
    pause
    goto main_menu
)
echo Video duration: !total_seconds! seconds
echo [%date% %time%] Video duration: !total_seconds! seconds >> "!log_file!"

:: Get original FPS
echo Getting original FPS...
echo [%date% %time%] Getting original FPS... >> "!log_file!"
set "original_fps=0"
set "temp_file=%TEMP%\ffmpeg_fps.txt"
"!ffmpeg_path!" -hide_banner -i "!video_file!" 2>"!temp_file!"
for /f "tokens=1" %%i in ('type "!temp_file!" ^| findstr /r /c:"[0-9]*\.[0-9]* fps"') do (
    set "original_fps=%%i"
    echo Original FPS: !original_fps!
    echo [%date% %time%] Original FPS: !original_fps! >> "!log_file!"
)
del "!temp_file!"
if "!original_fps!"=="0" (
    echo Warning: Could not detect original FPS, assuming 30
    echo [%date% %time%] Warning: Could not detect original FPS, assuming 30 >> "!log_file!"
    set "original_fps=30"
)

:: Process audio
echo Extracting audio...
echo [%date% %time%] Extracting audio... >> "!log_file!"
set "audio_log=%~dp0ffmpeg_audio_error.log"
set "audio_cmd="!ffmpeg_path!" -i "!video_file!" -vn -acodec mp3 -threads 0 -preset ultrafast "!video_path!\background.mp3" -y -nostats -loglevel error"
echo Audio command: !audio_cmd!
echo [%date% %time%] Audio command: !audio_cmd! >> "!log_file!"
!audio_cmd! 2>"!audio_log!"
set "ffmpeg_errorlevel=!errorlevel!"
echo [%date% %time%] FFmpeg audio extraction completed with errorlevel: !ffmpeg_errorlevel! >> "!log_file!"
if !ffmpeg_errorlevel! neq 0 (
    echo Error: Audio extraction failed with errorlevel !ffmpeg_errorlevel!
    echo [%date% %time%] Error: Audio extraction failed with errorlevel !ffmpeg_errorlevel! >> "!log_file!"
    if exist "!audio_log!" (
        echo FFmpeg audio error log:
        type "!audio_log!"
        echo [%date% %time%] FFmpeg audio error log contents: >> "!log_file!"
        type "!audio_log!" >> "!log_file!"
    )
    del "!audio_log!" 2>nul
    pause
    goto main_menu
)
echo [%date% %time%] Checking if audio file exists: "!video_path!\background.mp3" >> "!log_file!"
if not exist "!video_path!\background.mp3" (
    echo Error: Audio file not created!
    echo [%date% %time%] Error: Audio file "!video_path!\background.mp3" not created >> "!log_file!"
    if exist "!audio_log!" (
        echo FFmpeg audio error log:
        type "!audio_log!"
        echo [%date% %time%] FFmpeg audio error log contents: >> "!log_file!"
        type "!audio_log!" >> "!log_file!"
    )
    del "!audio_log!" 2>nul
    pause
    goto main_menu
)
del "!audio_log!" 2>nul
echo Audio extracted successfully.
echo [%date% %time%] Audio extracted successfully to "!video_path!\background.mp3" >> "!log_file!"

:: Process frames
echo Extracting frames...
echo [%date% %time%] Extracting frames... >> "!log_file!"
rd /s /q "!frames_path!" 2>nul
mkdir "!frames_path!" 2>nul
set "frames_log=%~dp0ffmpeg_frames_error.log"
set "ffmpeg_cmd="
if "!fps!"=="1" (
    set "ffmpeg_cmd="!ffmpeg_path!" -i "!video_file!" !scale! -an !quality_setting! -threads 0 -preset ultrafast "!frames_path!\frame_%%04d.!img_format!" -y -nostats -loglevel error"
) else (
    set "ffmpeg_cmd="!ffmpeg_path!" -i "!video_file!" !scale! -r !fps_rate!/1 !quality_setting! -threads 0 -preset ultrafast "!frames_path!\frame_%%04d.!img_format!" -y -nostats -loglevel error"
)
echo Frames command: !ffmpeg_cmd!
echo [%date% %time%] Frames command: !ffmpeg_cmd! >> "!log_file!"
!ffmpeg_cmd! 2>"!frames_log!"
set "ffmpeg_errorlevel=!errorlevel!"
echo [%date% %time%] FFmpeg frame extraction completed with errorlevel: !ffmpeg_errorlevel! >> "!log_file!"
if !ffmpeg_errorlevel! neq 0 (
    echo Error: Frame extraction failed with errorlevel !ffmpeg_errorlevel!
    echo [%date% %time%] Error: Frame extraction failed with errorlevel !ffmpeg_errorlevel! >> "!log_file!"
    if exist "!frames_log!" (
        echo FFmpeg frames error log:
        type "!frames_log!"
        echo [%date% %time%] FFmpeg frames error log contents: >> "!log_file!"
        type "!frames_log!" >> "!log_file!"
    )
    del "!frames_log!" 2>nul
    pause
    goto main_menu
)
for /f %%a in ('dir "!frames_path!" /b /a-d 2^>nul ^| find /c /v ""') do set "frame_count=%%a"
if !frame_count! equ 0 (
    echo Error: No frames extracted!
    echo [%date% %time%] Error: No frames extracted >> "!log_file!"
    if exist "!frames_log!" (
        echo FFmpeg frames error log:
        type "!frames_log!"
        echo [%date% %time%] FFmpeg frames error log contents: >> "!log_file!"
        type "!frames_log!" >> "!log_file!"
    )
    del "!frames_log!" 2>nul
    pause
    goto main_menu
)
set /a "expected_frames=total_seconds*fps_rate" 2>nul
if "!fps!"=="1" set /a "expected_frames=total_seconds*original_fps" 2>nul
echo Extracted !frame_count! frames ^(Expected ~!expected_frames!^)
echo [%date% %time%] Extracted !frame_count! frames (Expected ~!expected_frames!) >> "!log_file!"
del "!frames_log!" 2>nul
echo Frames extracted successfully.
echo [%date% %time%] Frames extracted successfully to "!frames_path!" >> "!log_file!"

echo Done! Audio: !video_path!\background.mp3  Frames: !frames_path!
echo [%date% %time%] Processing complete: Audio at "!video_path!\background.mp3", Frames at "!frames_path!" >> "!log_file!"
pause
goto main_menu